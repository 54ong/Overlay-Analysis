﻿namespace Overlay_Analysis
{
    partial class Fieldset
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.FieldList = new System.Windows.Forms.ListView();
            this.label2 = new System.Windows.Forms.Label();
            this.FieldList1 = new System.Windows.Forms.ListView();
            this.btnsa = new System.Windows.Forms.Button();
            this.btnsi = new System.Windows.Forms.Button();
            this.btnsa1 = new System.Windows.Forms.Button();
            this.btnsi1 = new System.Windows.Forms.Button();
            this.btnok = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "来自源数据的字段：";
            // 
            // FieldList
            // 
            this.FieldList.Location = new System.Drawing.Point(15, 57);
            this.FieldList.Name = "FieldList";
            this.FieldList.Size = new System.Drawing.Size(300, 174);
            this.FieldList.TabIndex = 1;
            this.FieldList.UseCompatibleStateImageBehavior = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(252, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "来自叠加数据的字段：";
            // 
            // FieldList1
            // 
            this.FieldList1.Location = new System.Drawing.Point(356, 57);
            this.FieldList1.Name = "FieldList1";
            this.FieldList1.Size = new System.Drawing.Size(315, 174);
            this.FieldList1.TabIndex = 3;
            this.FieldList1.UseCompatibleStateImageBehavior = false;
            // 
            // btnsa
            // 
            this.btnsa.Location = new System.Drawing.Point(15, 247);
            this.btnsa.Name = "btnsa";
            this.btnsa.Size = new System.Drawing.Size(75, 38);
            this.btnsa.TabIndex = 4;
            this.btnsa.Text = "全选";
            this.btnsa.UseVisualStyleBackColor = true;
            this.btnsa.Click += new System.EventHandler(this.btnsa_Click);
            // 
            // btnsi
            // 
            this.btnsi.Location = new System.Drawing.Point(130, 247);
            this.btnsi.Name = "btnsi";
            this.btnsi.Size = new System.Drawing.Size(75, 38);
            this.btnsi.TabIndex = 5;
            this.btnsi.Text = "反选";
            this.btnsi.UseVisualStyleBackColor = true;
            this.btnsi.Click += new System.EventHandler(this.btnsi_Click);
            // 
            // btnsa1
            // 
            this.btnsa1.Location = new System.Drawing.Point(255, 247);
            this.btnsa1.Name = "btnsa1";
            this.btnsa1.Size = new System.Drawing.Size(75, 38);
            this.btnsa1.TabIndex = 6;
            this.btnsa1.Text = "全选";
            this.btnsa1.UseVisualStyleBackColor = true;
            this.btnsa1.Click += new System.EventHandler(this.btnsa1_Click);
            // 
            // btnsi1
            // 
            this.btnsi1.Location = new System.Drawing.Point(370, 247);
            this.btnsi1.Name = "btnsi1";
            this.btnsi1.Size = new System.Drawing.Size(75, 38);
            this.btnsi1.TabIndex = 7;
            this.btnsi1.Text = "反选";
            this.btnsi1.UseVisualStyleBackColor = true;
            this.btnsi1.Click += new System.EventHandler(this.btnsi1_Click);
            // 
            // btnok
            // 
            this.btnok.Location = new System.Drawing.Point(305, 307);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(75, 38);
            this.btnok.TabIndex = 8;
            this.btnok.Text = "确定";
            this.btnok.UseVisualStyleBackColor = true;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // btncancel
            // 
            this.btncancel.Location = new System.Drawing.Point(395, 307);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 38);
            this.btncancel.TabIndex = 9;
            this.btncancel.Text = "取消";
            this.btncancel.UseVisualStyleBackColor = true;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(707, 357);
            this.shapeContainer1.TabIndex = 10;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape1
            // 
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 2;
            this.lineShape1.X2 = 489;
            this.lineShape1.Y1 = 297;
            this.lineShape1.Y2 = 296;
            // 
            // Fieldset
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(707, 357);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.btnok);
            this.Controls.Add(this.btnsi1);
            this.Controls.Add(this.btnsa1);
            this.Controls.Add(this.btnsi);
            this.Controls.Add(this.btnsa);
            this.Controls.Add(this.FieldList1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.FieldList);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.shapeContainer1);
            this.Name = "Fieldset";
            this.Text = "字段设置";
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.ListView FieldList;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView FieldList1;
        private System.Windows.Forms.Button btnsa;
        private System.Windows.Forms.Button btnsi;
        private System.Windows.Forms.Button btnsa1;
        private System.Windows.Forms.Button btnsi1;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.Button btncancel;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
    }
}
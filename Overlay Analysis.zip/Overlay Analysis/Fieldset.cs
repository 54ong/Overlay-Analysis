﻿using SuperMap.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Overlay_Analysis
{
    public partial class Fieldset : Form
    {
      //用全局变量来保存传过来的两个数据集
        public static DatasetVector originaldt = null;
        public static DatasetVector targetdt = null;
        //用公有属性来保存两个数据集的保留字段
        public static string[] originalarr { get; set; }
        public static string[] targetarr { get; set; }

       

        public Fieldset(DatasetVector ods,DatasetVector tds)
        {   
            InitializeComponent();
            //获取上一个窗体选择的两个数据集
             originaldt=ods;
             targetdt = tds;
           
            //对字段进行构造
            FieldList.View = View.Details;
            FieldList1.View = View.Details;
            ColumnHeader ch = new ColumnHeader();
            ColumnHeader ch0 = new ColumnHeader();
            ch.Text = "索引";
            ch0.Text = "索引";
            FieldList.Columns.Add(ch);
            FieldList1.Columns.Add(ch0);
            ColumnHeader ch1 = new ColumnHeader();
            ch1.Text = "字段信息";
            ColumnHeader ch2 = new ColumnHeader();
            ch2.Text = "字段信息";
            FieldList.Columns.Add(ch1);
            FieldList1.Columns.Add(ch2);
            //用一个集合来保存所有系统字段
            List<string> Sysfiled = new List<string>{ "SmID", "SmUserID", "SmArea", "SmPerimeter", "SmGeometrySize" };
           
            //将索引和字段都添加到控件里
            for (int i = 0; i < originaldt.FieldCount; i++)
            {
               
                //排除系统字段     
                if(!Sysfiled.Contains(originaldt.FieldInfos[i].Name))

                {
                ListViewItem lvi=new ListViewItem();
                string b = originaldt.FieldInfos[i].Name;
                lvi.Text = i.ToString();
                lvi.SubItems.Add(b); 
                FieldList.Items.Add(lvi);
                }
                         
                 
            }

            for (int i = 0; i < targetdt.FieldCount; i++)
            {
                if (!Sysfiled.Contains(targetdt.FieldInfos[i].Name))
                {
                ListViewItem lvi = new ListViewItem();
                string a = targetdt.FieldInfos[i].Name;
                lvi.Text = i.ToString();
                lvi.SubItems.Add(a);
                FieldList1.Items.Add(lvi);
                }
               

             

            }
            //显示出复选框
            FieldList.CheckBoxes = true;
            FieldList1.CheckBoxes = true;
    
            //DatasetVector targetdt = DS.tds;
        }

        private void btnsa_Click(object sender, EventArgs e)//源数据集全选
        {
            foreach (ListViewItem item in FieldList.Items)
            {
                item.Checked = true;
            }
 
        }

        private void btnsi_Click(object sender, EventArgs e)//源数据集反选
        {
            foreach (ListViewItem item in FieldList.Items)
            {
                item.Checked = false;
            }
        }

        private void btnsa1_Click(object sender, EventArgs e)//叠加数据集全选
        {
            foreach (ListViewItem item in FieldList1.Items)
            {
                item.Checked = true;
            }
        }

        private void btnsi1_Click(object sender, EventArgs e)//叠加数据集反选
        {
            foreach (ListViewItem item in FieldList1.Items)
            {
                item.Checked = false;
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnok_Click(object sender, EventArgs e)
        {
            List<string> arr = new List<string>();
            List<string> arr1 = new List<string>();
            //根据复选框的情况来筛选字段
            foreach (ListViewItem item in FieldList.Items)
            {
                if (item.Checked == true)
                   arr.Add(item.SubItems[1].Text);                
            }

            foreach (ListViewItem item in FieldList1.Items)
            {
                if (item.Checked == false)
                   arr1.Add(item.SubItems[1].Text);
            }
            
            originalarr = arr.ToArray();
            targetarr = arr1.ToArray();
            this.Close();
        
        }

       
       
    }
}

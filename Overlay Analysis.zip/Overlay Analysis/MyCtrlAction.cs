using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using SuperMap.Desktop;

namespace Overlay_Analysis
{
    class MyCtrlAction : CtrlAction
    {
        public MyCtrlAction(IBaseItem caller)
            : base(caller)
        {

        }

        override public void Run()
        {
            //To do your work.
            //Example:

            //չʾ����
            O_A OA = new O_A();
            OA.Show();

            IBaseItem baseItem = this.Caller;
            if (baseItem != null)
            {
                String itemType = baseItem.GetType().ToString().Replace("SuperMap.Desktop.", "");
                //MessageBox.Show(String.Format("This is a \"{0}\"!", itemType));
            }

        }
    }
}

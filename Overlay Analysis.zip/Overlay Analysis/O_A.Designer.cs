﻿namespace Overlay_Analysis
{
    partial class O_A
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbUpdate = new System.Windows.Forms.RadioButton();
            this.rbclipResult = new System.Windows.Forms.RadioButton();
            this.rbXOR = new System.Windows.Forms.RadioButton();
            this.rbUnion = new System.Windows.Forms.RadioButton();
            this.rbIdentity = new System.Windows.Forms.RadioButton();
            this.rbErase = new System.Windows.Forms.RadioButton();
            this.tbIntersect = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tboriginalDS = new System.Windows.Forms.TextBox();
            this.cboriginalDataset = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tbtargetDS = new System.Windows.Forms.TextBox();
            this.cboverlayDs = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.tbresultDs = new System.Windows.Forms.TextBox();
            this.cbcompare = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbTolerance = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnFieldSet = new System.Windows.Forms.Button();
            this.tbdatasetResult = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnok = new System.Windows.Forms.Button();
            this.btnclose = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.workspace1 = new SuperMap.Data.Workspace(this.components);
            this.workspace2 = new SuperMap.Data.Workspace(this.components);
            this.workspace3 = new SuperMap.Data.Workspace(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Controls.Add(this.rbUpdate);
            this.groupBox1.Controls.Add(this.rbclipResult);
            this.groupBox1.Controls.Add(this.rbXOR);
            this.groupBox1.Controls.Add(this.rbUnion);
            this.groupBox1.Controls.Add(this.rbIdentity);
            this.groupBox1.Controls.Add(this.rbErase);
            this.groupBox1.Controls.Add(this.tbIntersect);
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(14, 34);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(116, 544);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "类型";
            // 
            // rbUpdate
            // 
            this.rbUpdate.AutoSize = true;
            this.rbUpdate.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rbUpdate.Location = new System.Drawing.Point(18, 484);
            this.rbUpdate.Margin = new System.Windows.Forms.Padding(4);
            this.rbUpdate.Name = "rbUpdate";
            this.rbUpdate.Size = new System.Drawing.Size(60, 25);
            this.rbUpdate.TabIndex = 14;
            this.rbUpdate.TabStop = true;
            this.rbUpdate.Text = "更新";
            this.rbUpdate.UseVisualStyleBackColor = true;
            this.rbUpdate.Click += new System.EventHandler(this.rbUpdate_Click);
            // 
            // rbclipResult
            // 
            this.rbclipResult.AutoSize = true;
            this.rbclipResult.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rbclipResult.Location = new System.Drawing.Point(18, 30);
            this.rbclipResult.Margin = new System.Windows.Forms.Padding(4);
            this.rbclipResult.Name = "rbclipResult";
            this.rbclipResult.Size = new System.Drawing.Size(60, 25);
            this.rbclipResult.TabIndex = 8;
            this.rbclipResult.TabStop = true;
            this.rbclipResult.Text = "裁剪";
            this.rbclipResult.UseVisualStyleBackColor = true;
            this.rbclipResult.Click += new System.EventHandler(this.rbclipResult_Click);
            // 
            // rbXOR
            // 
            this.rbXOR.AutoSize = true;
            this.rbXOR.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rbXOR.Location = new System.Drawing.Point(18, 408);
            this.rbXOR.Margin = new System.Windows.Forms.Padding(4);
            this.rbXOR.Name = "rbXOR";
            this.rbXOR.Size = new System.Drawing.Size(76, 25);
            this.rbXOR.TabIndex = 13;
            this.rbXOR.TabStop = true;
            this.rbXOR.Text = "对称差";
            this.rbXOR.UseVisualStyleBackColor = true;
            this.rbXOR.Click += new System.EventHandler(this.rbXOR_Click);
            // 
            // rbUnion
            // 
            this.rbUnion.AutoSize = true;
            this.rbUnion.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rbUnion.Location = new System.Drawing.Point(18, 98);
            this.rbUnion.Margin = new System.Windows.Forms.Padding(4);
            this.rbUnion.Name = "rbUnion";
            this.rbUnion.Size = new System.Drawing.Size(60, 25);
            this.rbUnion.TabIndex = 9;
            this.rbUnion.TabStop = true;
            this.rbUnion.Text = "合并";
            this.rbUnion.UseVisualStyleBackColor = true;
            this.rbUnion.Click += new System.EventHandler(this.rbUnion_Click);
            // 
            // rbIdentity
            // 
            this.rbIdentity.AutoSize = true;
            this.rbIdentity.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rbIdentity.Location = new System.Drawing.Point(18, 332);
            this.rbIdentity.Margin = new System.Windows.Forms.Padding(4);
            this.rbIdentity.Name = "rbIdentity";
            this.rbIdentity.Size = new System.Drawing.Size(60, 25);
            this.rbIdentity.TabIndex = 12;
            this.rbIdentity.TabStop = true;
            this.rbIdentity.Text = "同一";
            this.rbIdentity.UseVisualStyleBackColor = true;
            this.rbIdentity.Click += new System.EventHandler(this.rbIdentity_Click);
            // 
            // rbErase
            // 
            this.rbErase.AutoSize = true;
            this.rbErase.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.rbErase.Location = new System.Drawing.Point(18, 178);
            this.rbErase.Margin = new System.Windows.Forms.Padding(4);
            this.rbErase.Name = "rbErase";
            this.rbErase.Size = new System.Drawing.Size(60, 25);
            this.rbErase.TabIndex = 10;
            this.rbErase.TabStop = true;
            this.rbErase.Text = "擦除";
            this.rbErase.UseVisualStyleBackColor = true;
            this.rbErase.Click += new System.EventHandler(this.rbErase_Click);
            // 
            // tbIntersect
            // 
            this.tbIntersect.AutoSize = true;
            this.tbIntersect.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tbIntersect.Location = new System.Drawing.Point(18, 255);
            this.tbIntersect.Margin = new System.Windows.Forms.Padding(4);
            this.tbIntersect.Name = "tbIntersect";
            this.tbIntersect.Size = new System.Drawing.Size(60, 25);
            this.tbIntersect.TabIndex = 11;
            this.tbIntersect.TabStop = true;
            this.tbIntersect.Text = "求交";
            this.tbIntersect.UseVisualStyleBackColor = true;
            this.tbIntersect.CheckedChanged += new System.EventHandler(this.tbIntersect_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox2.Controls.Add(this.tboriginalDS);
            this.groupBox2.Controls.Add(this.cboriginalDataset);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.Location = new System.Drawing.Point(168, 34);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(329, 123);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "数据源";
            // 
            // tboriginalDS
            // 
            this.tboriginalDS.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tboriginalDS.Location = new System.Drawing.Point(84, 34);
            this.tboriginalDS.Margin = new System.Windows.Forms.Padding(4);
            this.tboriginalDS.Name = "tboriginalDS";
            this.tboriginalDS.ReadOnly = true;
            this.tboriginalDS.Size = new System.Drawing.Size(210, 29);
            this.tboriginalDS.TabIndex = 10;
            this.tboriginalDS.Text = "点击这里选择数据源";
            this.tboriginalDS.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tboriginalDs_MouseClick);
            // 
            // cboriginalDataset
            // 
            this.cboriginalDataset.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.cboriginalDataset.FormattingEnabled = true;
            this.cboriginalDataset.Location = new System.Drawing.Point(84, 89);
            this.cboriginalDataset.Margin = new System.Windows.Forms.Padding(4);
            this.cboriginalDataset.Name = "cboriginalDataset";
            this.cboriginalDataset.Size = new System.Drawing.Size(210, 29);
            this.cboriginalDataset.TabIndex = 9;
            this.cboriginalDataset.DropDown += new System.EventHandler(this.cboriginalDataset_DropDown);
            this.cboriginalDataset.DropDownClosed += new System.EventHandler(this.cboriginalDataset_DropDownClosed);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(7, 89);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "数据集：";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(7, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "数据源：";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox3.Controls.Add(this.tbtargetDS);
            this.groupBox3.Controls.Add(this.cboverlayDs);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox3.Location = new System.Drawing.Point(168, 200);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox3.Size = new System.Drawing.Size(329, 123);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "叠加数据";
            // 
            // tbtargetDS
            // 
            this.tbtargetDS.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbtargetDS.Location = new System.Drawing.Point(84, 34);
            this.tbtargetDS.Margin = new System.Windows.Forms.Padding(4);
            this.tbtargetDS.Name = "tbtargetDS";
            this.tbtargetDS.ReadOnly = true;
            this.tbtargetDS.Size = new System.Drawing.Size(210, 29);
            this.tbtargetDS.TabIndex = 10;
            this.tbtargetDS.Text = "点击这里选择数据源";
            this.tbtargetDS.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tbtargetDs_MouseClick);
            // 
            // cboverlayDs
            // 
            this.cboverlayDs.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.cboverlayDs.FormattingEnabled = true;
            this.cboverlayDs.Location = new System.Drawing.Point(84, 89);
            this.cboverlayDs.Margin = new System.Windows.Forms.Padding(4);
            this.cboverlayDs.Name = "cboverlayDs";
            this.cboverlayDs.Size = new System.Drawing.Size(210, 29);
            this.cboverlayDs.TabIndex = 9;
            this.cboverlayDs.DropDown += new System.EventHandler(this.cboverlayDs_DropDown);
            this.cboverlayDs.DropDownClosed += new System.EventHandler(this.cboverlayDs_DropDownClosed);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(7, 89);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 21);
            this.label3.TabIndex = 1;
            this.label3.Text = "数据集：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(7, 34);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(74, 21);
            this.label4.TabIndex = 0;
            this.label4.Text = "数据源：";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox4.Controls.Add(this.tbresultDs);
            this.groupBox4.Controls.Add(this.cbcompare);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.tbTolerance);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.btnFieldSet);
            this.groupBox4.Controls.Add(this.tbdatasetResult);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox4.Location = new System.Drawing.Point(168, 357);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox4.Size = new System.Drawing.Size(329, 221);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "结果设置";
            // 
            // tbresultDs
            // 
            this.tbresultDs.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbresultDs.Location = new System.Drawing.Point(84, 26);
            this.tbresultDs.Margin = new System.Windows.Forms.Padding(4);
            this.tbresultDs.Name = "tbresultDs";
            this.tbresultDs.ReadOnly = true;
            this.tbresultDs.Size = new System.Drawing.Size(210, 29);
            this.tbresultDs.TabIndex = 12;
            this.tbresultDs.Text = "点击这里选择数据源";
            this.tbresultDs.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tbresultDs_MouseClick);
            // 
            // cbcompare
            // 
            this.cbcompare.AutoSize = true;
            this.cbcompare.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.cbcompare.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cbcompare.Location = new System.Drawing.Point(10, 178);
            this.cbcompare.Margin = new System.Windows.Forms.Padding(4);
            this.cbcompare.Name = "cbcompare";
            this.cbcompare.Size = new System.Drawing.Size(125, 25);
            this.cbcompare.TabIndex = 11;
            this.cbcompare.Text = "进行结果对比";
            this.cbcompare.UseVisualStyleBackColor = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.Location = new System.Drawing.Point(301, 132);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 21);
            this.label8.TabIndex = 11;
            this.label8.Text = "米";
            // 
            // tbTolerance
            // 
            this.tbTolerance.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbTolerance.Location = new System.Drawing.Point(84, 128);
            this.tbTolerance.Margin = new System.Windows.Forms.Padding(4);
            this.tbTolerance.Name = "tbTolerance";
            this.tbTolerance.Size = new System.Drawing.Size(210, 29);
            this.tbTolerance.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.Location = new System.Drawing.Point(8, 136);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 21);
            this.label7.TabIndex = 5;
            this.label7.Text = "容限：";
            // 
            // btnFieldSet
            // 
            this.btnFieldSet.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnFieldSet.Location = new System.Drawing.Point(200, 85);
            this.btnFieldSet.Margin = new System.Windows.Forms.Padding(4);
            this.btnFieldSet.Name = "btnFieldSet";
            this.btnFieldSet.Size = new System.Drawing.Size(98, 30);
            this.btnFieldSet.TabIndex = 4;
            this.btnFieldSet.Text = "字段设置...";
            this.btnFieldSet.UseVisualStyleBackColor = false;
            this.btnFieldSet.Click += new System.EventHandler(this.btnFieldSet_Click);
            // 
            // tbdatasetResult
            // 
            this.tbdatasetResult.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tbdatasetResult.Location = new System.Drawing.Point(84, 85);
            this.tbdatasetResult.Margin = new System.Windows.Forms.Padding(4);
            this.tbdatasetResult.Name = "tbdatasetResult";
            this.tbdatasetResult.Size = new System.Drawing.Size(109, 29);
            this.tbdatasetResult.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(7, 89);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(74, 21);
            this.label5.TabIndex = 1;
            this.label5.Text = "数据集：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(7, 34);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 21);
            this.label6.TabIndex = 0;
            this.label6.Text = "数据源：";
            // 
            // btnok
            // 
            this.btnok.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnok.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnok.Location = new System.Drawing.Point(307, 602);
            this.btnok.Margin = new System.Windows.Forms.Padding(4);
            this.btnok.Name = "btnok";
            this.btnok.Size = new System.Drawing.Size(80, 42);
            this.btnok.TabIndex = 11;
            this.btnok.Text = "确定";
            this.btnok.UseVisualStyleBackColor = false;
            this.btnok.Click += new System.EventHandler(this.btnok_Click);
            // 
            // btnclose
            // 
            this.btnclose.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.btnclose.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnclose.Location = new System.Drawing.Point(404, 602);
            this.btnclose.Margin = new System.Windows.Forms.Padding(4);
            this.btnclose.Name = "btnclose";
            this.btnclose.Size = new System.Drawing.Size(91, 42);
            this.btnclose.TabIndex = 12;
            this.btnclose.Text = "取消";
            this.btnclose.UseVisualStyleBackColor = false;
            this.btnclose.Click += new System.EventHandler(this.btnclose_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // workspace1
            // 
            this.workspace1.Caption = "UntitledWorkspace";
            this.workspace1.Description = "";
            // 
            // workspace2
            // 
            this.workspace2.Caption = "UntitledWorkspace";
            this.workspace2.Description = "";
            // 
            // workspace3
            // 
            this.workspace3.Caption = "UntitledWorkspace";
            this.workspace3.Description = "";
            // 
            // O_A
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(542, 668);
            this.Controls.Add(this.btnclose);
            this.Controls.Add(this.btnok);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "O_A";
            this.Text = "叠加分析";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbUpdate;
        private System.Windows.Forms.RadioButton rbclipResult;
        private System.Windows.Forms.RadioButton rbXOR;
        private System.Windows.Forms.RadioButton rbUnion;
        private System.Windows.Forms.RadioButton rbIdentity;
        private System.Windows.Forms.RadioButton rbErase;
        private System.Windows.Forms.RadioButton tbIntersect;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.CheckBox cbcompare;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnFieldSet;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnok;
        private System.Windows.Forms.Button btnclose;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        public System.Windows.Forms.ComboBox cboriginalDataset;
        public System.Windows.Forms.ComboBox cboverlayDs;
        public System.Windows.Forms.TextBox tbTolerance;
        public System.Windows.Forms.TextBox tbdatasetResult;
        public System.Windows.Forms.TextBox tboriginalDS;
        public System.Windows.Forms.TextBox tbtargetDS;
        public System.Windows.Forms.TextBox tbresultDs;
        public SuperMap.Data.Workspace workspace1;
        public SuperMap.Data.Workspace workspace2;
        public SuperMap.Data.Workspace workspace3;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SuperMap.Analyst.SpatialAnalyst;
using SuperMap.Data;
using SuperMap.Desktop.UI;
using SuperMap.Mapping;

namespace Overlay_Analysis
{
   
    
    //勾选“进行结果对比”复选框，可将被裁剪数据集、裁剪数据集及结果数据集同时
    //显示在一个新的地图窗口中，便于用户进行结果的比较。
    public partial class O_A : Form
    {
        #region 辅助的变量及方法等
        static Datasource store; //用来保存第一个数据源，方便被第二个调用。
        static int type;//用来记录操作类型
        static  DatasetVector originaldt;//用来保存选中的源数据集
       static  DatasetVector targetdt;//用来保存选中的叠加数据集
       static int compare;//记录是否对结果进行对比
      //用来自动改变结果数据集名字
        
        /// <summary>
        /// 将数据集添加至下拉控件中(点，线，面数据集)
        /// </summary>
        /// <param name="dataset">要被遍历的数据集</param>
        /// <param name="cb">要添加的控件</param>
        public void comboboxAdd(DatasetVector dataset, ComboBox cb)
        {
            if (dataset.Type == DatasetType.Point || dataset.Type == DatasetType.Line || dataset.Type == DatasetType.Region)
                cb.Items.Add(dataset);
        }

        /// <summary>
        /// 将数据集添加至下拉控件中(面数据集)
        /// </summary>
        /// <param name="dataset">要被遍历的数据集</param>
        /// <param name="cb">要添加的控件</param>
        public void comboboxAdd1(DatasetVector dataset, ComboBox cb)
        {
            if (dataset.Type == DatasetType.Region)
                cb.Items.Add(dataset);
        }

        #endregion
       
        public O_A()
        {
            InitializeComponent();
            openFileDialog1.Filter = "数据源文件|*.udb";//限定只能选择文件型数据源
            tbTolerance.Text = "40.0750166855785";//对容限进行初始化
        }
       

        #region 文本框代码
        private void tboriginalDs_MouseClick(object sender, MouseEventArgs e)
        {
            //打开浏览窗口,显示选择的数据源
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                tboriginalDS.Text = System.IO.Path.GetFileNameWithoutExtension(openFileDialog1.FileName);
        }

        private void tbtargetDs_MouseClick(object sender, MouseEventArgs e)
        {
            //打开浏览窗口,显示选择的数据源
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                tbtargetDS.Text = System.IO.Path.GetFileNameWithoutExtension(openFileDialog1.FileName);
        }

        private void tbresultDs_MouseClick(object sender, MouseEventArgs e)
        {
            //打开浏览窗口,显示选择的数据源
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                tbresultDs.Text = System.IO.Path.GetFileNameWithoutExtension(openFileDialog1.FileName);
        }
        #endregion

        #region 单选框代码
        private void rbclipResult_Click(object sender, EventArgs e)
        {
            //将对应类型的默认命名显示出来,并判断是否禁用‘字段设置’
            Random random=new Random();
            int i=random.Next(1,100);
            tbdatasetResult.Text = "ClipResult"+i.ToString();
            btnFieldSet.Enabled = false;
            type = 1;
        }

        private void rbUnion_Click(object sender, EventArgs e)
        {
            //将对应类型的默认命名显示出来,并判断是否禁用‘字段设置’
             Random random=new Random();
            int i=random.Next(1,100);
            tbdatasetResult.Text = "UnionResult"+i.ToString();
            btnFieldSet.Enabled = true;
            type = 2;
            
        }

        private void rbErase_Click(object sender, EventArgs e)
        {
            //将对应类型的默认命名显示出来,并判断是否禁用‘字段设置’
             Random random=new Random();
            int i=random.Next(1,100);
            tbdatasetResult.Text = "EraseResult"+i.ToString();
            btnFieldSet.Enabled = false;
            type = 3;
        }

        private void tbIntersect_CheckedChanged(object sender, EventArgs e)
        {
            //将对应类型的默认命名显示出来,并判断是否禁用‘字段设置’
             Random random=new Random();
            int i=random.Next(1,100);
            tbdatasetResult.Text = "IntersectResult"+i.ToString();
            btnFieldSet.Enabled = true;
            type = 4;
        }

        private void rbIdentity_Click(object sender, EventArgs e)
        {
            //将对应类型的默认命名显示出来,并判断是否禁用‘字段设置’
             Random random=new Random();
            int i=random.Next(1,100);
            tbdatasetResult.Text = "IdentityResult"+i.ToString();
            btnFieldSet.Enabled = true;
            type = 5;
        }

        private void rbXOR_Click(object sender, EventArgs e)
        {
            //将对应类型的默认命名显示出来,并判断是否禁用‘字段设置’
             Random random=new Random();
            int i=random.Next(1,100);
            tbdatasetResult.Text = "XORResult"+i.ToString();
            btnFieldSet.Enabled = true;
            type = 6;
        }

        private void rbUpdate_Click(object sender, EventArgs e)
        {
            //将对应类型的默认命名显示出来,并判断是否禁用‘字段设置’
             Random random=new Random();
            int i=random.Next(1,100);
            tbdatasetResult.Text = "UpdateResult"+i.ToString();
            btnFieldSet.Enabled = false;
            type = 7;
        }
        #endregion

        #region 下拉框代码
       

        private void cboriginalDataset_DropDown(object sender, EventArgs e)
        {
            //如果下拉框里已有选中值了但要重新选，则先清理掉所有选项
            if (cboriginalDataset.SelectedItem != null)
                cboriginalDataset.Items.Clear();


            if (tboriginalDS.Text == "点击这里选择数据源")
                MessageBox.Show("请先选择数据源");
            else
            {
                if (workspace1.Datasources.Count == 0)//防止重复加载
                {
                    //获取数据源
                    DatasourceConnectionInfo dci = new DatasourceConnectionInfo();
                    dci.Server = @System.IO.Path.GetFullPath(openFileDialog1.FileName);

                    Datasource originalDs = workspace1.Datasources.Open(dci);
                    store = originalDs;//保存到全局变量中
                }


                foreach (DatasetVector a in store.Datasets)
                {

                    cboriginalDataset.DisplayMember = "a.Name";
                    cboriginalDataset.ValueMember = "a.FieldCount";
                    //根据操作类型来判断添加哪些数据集
                    switch (type)
                    {
                        case 1: comboboxAdd(a, cboriginalDataset); break;
                        case 2: comboboxAdd1(a, cboriginalDataset); break;
                        case 3: comboboxAdd(a, cboriginalDataset); break;
                        case 4: comboboxAdd(a, cboriginalDataset); break;
                        case 5: comboboxAdd(a, cboriginalDataset); break;
                        case 6: comboboxAdd1(a, cboriginalDataset); break;
                        case 7: comboboxAdd1(a, cboriginalDataset); break;
                    }


                }
            }
                        
        }

        private void cboverlayDs_DropDown(object sender, EventArgs e)
        {
            //如果下拉框里已有选中值了但要重新选，则先清理掉所有选项
            if (cboverlayDs.SelectedItem != null)
                cboverlayDs.Items.Clear();

            if (tbtargetDS.Text == "点击这里选择数据源")
                MessageBox.Show("请先选择数据源");
            else
            {
                if (workspace2.Datasources.Count == 0)//防止重复加载
                {
                    //获取数据源
                    //判断和原数据源是否一样
                    Datasource targetDs;
                    if (tbtargetDS.Text != tboriginalDS.Text)
                    {
                        DatasourceConnectionInfo dci1 = new DatasourceConnectionInfo();
                        dci1.Server = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                        targetDs = workspace2.Datasources.Open(dci1);
                    }
                    else
                    {
                        targetDs = store;
                    }
                    //获取选中数据源中的数据集,并把面数据集添加到控件中
                    foreach (Dataset a in targetDs.Datasets)
                    {
                        cboverlayDs.DisplayMember = "a.Name";

                        if (a.Type == DatasetType.Region)
                            cboverlayDs.Items.Add(a);

                    }
                }
            }
        }

        private void cboriginalDataset_DropDownClosed(object sender, EventArgs e)
        {
            //当下拉框收起时且没有选中值时，清理掉里面的所有数据集
            if (cboriginalDataset.SelectedItem == null)
                cboriginalDataset.Items.Clear();
            else
            {
                //给容限文本框赋值
                DatasetVector dv=(DatasetVector)cboriginalDataset.SelectedItem;
                
            }
                
        }

        private void cboverlayDs_DropDownClosed(object sender, EventArgs e)
        {
            //当下拉框收起时且没有选中值时，清理掉里面的所有数据集
            if (cboverlayDs.SelectedItem == null)
                cboverlayDs.Items.Clear();
        }
        #endregion 
        
        #region 按钮代码
        private void btnFieldSet_Click(object sender, EventArgs e)
        {
            //弹出'字段设置'窗口
            
            originaldt=(DatasetVector) cboriginalDataset.SelectedItem;
            targetdt = (DatasetVector)cboverlayDs.SelectedItem;
            Fieldset fieldset= new Fieldset(originaldt,targetdt);            
            fieldset.Show();
            
        }

        private void btnclose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnok_Click(object sender, EventArgs e)
        {

            MessageBox.Show("分析中，请耐心等待几秒");
            OverlayAnalystParameter par=new OverlayAnalystParameter();//声明一个叠加分析参数对象
            par.Tolerance = double.Parse(tbTolerance.Text);//设置容限  
            //从'字段设置'窗体中接受传回来的保留字段数据，并赋给相应属性
            par.SourceRetainedFields = Fieldset.originalarr;
            par.OperationRetainedFields = Fieldset.targetarr;
            
            //par.SourceRetainedFields = 1;
          
            //<------------创建一个空白数据集-------------->
                Dataset originaldt = (DatasetVector)cboriginalDataset.SelectedItem;
                String resultDatasetClipName = tbdatasetResult.Text;
                DatasetVectorInfo datasetvectorInfoClip = new DatasetVectorInfo();
                datasetvectorInfoClip.Type = originaldt.Type;
                datasetvectorInfoClip.Name = resultDatasetClipName;
                datasetvectorInfoClip.EncodeType = EncodeType.None;
                DatasetVector result = store.Datasets.Create(datasetvectorInfoClip);    
           
            //<-----------------根据操作类型执行对应方法--------------------->
            switch (type)
            {
                case 1: OverlayAnalyst.Clip((DatasetVector)cboriginalDataset.SelectedItem, (DatasetVector)cboverlayDs.SelectedItem, result, par); break;
                case 2: OverlayAnalyst.Union((DatasetVector)cboriginalDataset.SelectedItem,(DatasetVector)cboverlayDs.SelectedItem, result, par); break;
                case 3: OverlayAnalyst.Erase((DatasetVector)cboriginalDataset.SelectedItem, (DatasetVector)cboverlayDs.SelectedItem, result, par); break;
                case 4: OverlayAnalyst.Intersect((DatasetVector)cboriginalDataset.SelectedItem, (DatasetVector)cboverlayDs.SelectedItem, result, par); break;
                case 5: OverlayAnalyst.Identity((DatasetVector)cboriginalDataset.SelectedItem, (DatasetVector)cboverlayDs.SelectedItem, result, par); break;
                case 6: OverlayAnalyst.XOR((DatasetVector)cboriginalDataset.SelectedItem, (DatasetVector)cboverlayDs.SelectedItem, result, par); break;
                case 7: OverlayAnalyst.Update((DatasetVector)cboriginalDataset.SelectedItem, (DatasetVector)cboverlayDs.SelectedItem, result, par); break;
            }

            
            compare = cbcompare.Checked == true ? 1 : 0;//记录是否要进行结果对比

            Result Result = new Result(result, (DatasetVector)cboriginalDataset.SelectedItem, (DatasetVector)cboverlayDs.SelectedItem,workspace1, compare);//将结果数据集对象传给Result窗体   
            Result.Show();
            
        }
        
   
        #endregion

       

       



    }
}

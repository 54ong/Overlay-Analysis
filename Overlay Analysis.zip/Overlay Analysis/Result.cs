﻿using SuperMap.Data;
using SuperMap.Mapping;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Overlay_Analysis
{
    public partial class Result : Form
    {
        public Result(DatasetVector rdt, DatasetVector odt, DatasetVector tdt,Workspace workspace, int compare)
        {
            
            InitializeComponent();
            ;
            
            //rdt = mapControl1.Map.Layers[0].Dataset as DatasetVector;
            mapControl1.Map.Workspace = workspace;

            if (compare == 0)
                mapControl1.Map.Layers.Add(rdt, true);
            else
            {
                mapControl1.Map.Layers.Add(odt, false);
                mapControl1.Map.Layers.Add(tdt, false);
            }
            mapControl1.Refresh();
        }

        private void Result_FormClosing(object sender, FormClosingEventArgs e)
        {
            mapControl1.Dispose();
        }



    }
}
